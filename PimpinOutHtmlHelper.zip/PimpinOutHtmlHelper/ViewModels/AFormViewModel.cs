﻿using System;

namespace PimpinOutHtmlHelper.ViewModels
{
    public class AFormViewModel
    {
        public string Name { get; set; }
    }
}
