﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Web.UI;

namespace PimpinOutHtmlHelper.Controllers
{

    [HandleError]
    public class AccountController : Controller
    {
        public ActionResult LogOn()
        {
            return View();
        }

        [AcceptVerbs(HttpVerbs.Post)]
        [ActionName("LogOn")]
        public ActionResult LogOn_Post()
        {
            System.Web.Security.FormsAuthentication.SetAuthCookie("me", false);
            return RedirectToAction("Index", "Home");
        }
    }
}
