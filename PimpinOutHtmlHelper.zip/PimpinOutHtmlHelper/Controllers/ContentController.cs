using System;
using System.Web.Mvc;
using PimpinOutHtmlHelper.Code;

namespace PimpinOutHtmlHelper.Controllers
{
    public class ContentController : Controller
    {
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateInput(false)]
        [Authorize]
        public ActionResult SaveContent(string id, string value)
        {
            string key = id.Replace("key_", String.Empty);

            var contentService = new ContentService();
            contentService.SetContent(key, value);

            return Content(value);
        }
    }
}
