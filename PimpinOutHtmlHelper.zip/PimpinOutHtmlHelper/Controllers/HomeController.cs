﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PimpinOutHtmlHelper.Code;
using PimpinOutHtmlHelper.ViewModels;

namespace PimpinOutHtmlHelper.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewData["Message"] = "Welcome to ASP.NET MVC!";

            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult AForm()
        {
            var vm = new AFormViewModel();
            vm.Name = "Hello from the controller";

            return View(vm);
        }

        [HttpPost]
        public ActionResult AForm(AFormViewModel vm)
        {
            if (String.IsNullOrEmpty(vm.Name))
                ModelState.AddModelError("Name", "UR doin' it wrong.");

            if (ModelState.IsValid)
                return RedirectToAction("Index");

            return View(vm);
        }
    }
}
