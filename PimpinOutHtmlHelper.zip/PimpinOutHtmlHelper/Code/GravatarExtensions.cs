﻿using System;
using System.Text;
using System.Security.Cryptography;
using System.Web.Mvc;

namespace PimpinOutHtmlHelper.Code
{
    public static class GravatarExtensions
    {
        public static string Gravatar(this HtmlHelper helper, string email, string size)
        {
            string src = "http://gravatar.com/avatar/" + HashIt(email) + ".jpg?s=" + size;
            return string.Format("<img class=\"avatar\" src=\"{0}\" width=\"{1}\" height=\"{1}\" alt=\"Gravatar\" />",
              src, size);      
        }

        private static string HashIt(string input)
        {
            byte[] result = ((HashAlgorithm)CryptoConfig.CreateFromName("MD5")).ComputeHash(Encoding.UTF8.GetBytes(input));

            return BitConverter.ToString(result).Replace("-", "").ToLower();
        }

    }
}
