﻿using System;
using System.Web.Mvc;

namespace PimpinOutHtmlHelper.Code
{
    public static class ContentExtensions
    {
        public static string Content(this HtmlHelper helper, string key)
        {
            var contentService = new ContentService();
            string content = contentService.GetContent(key);

            if (helper.ViewContext.RequestContext.HttpContext.User.Identity.IsAuthenticated && !String.IsNullOrEmpty(content))
                return "<div class=\"edit\" id=\"key_" + key + "\">" + content + "</div>";

            return content;
        }
    }
}
