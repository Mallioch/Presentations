﻿using System;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace PimpinOutHtmlHelper.Code
{
    public static class ValidationSummaryExtensions
    {
        public static MvcHtmlString WrappedValidationSummary(this HtmlHelper helper, string message)
        {
            if (helper.ViewData.ModelState.IsValid)
                return MvcHtmlString.Create(String.Empty);

            var div = new TagBuilder("div");
            div.AddCssClass("wrappedValidationSummary");

            var htmlString = MvcHtmlString.Create(div.ToString(TagRenderMode.StartTag)
                + helper.ValidationSummary(message)
                + div.ToString(TagRenderMode.EndTag));

            return htmlString;
        }
    }
}
