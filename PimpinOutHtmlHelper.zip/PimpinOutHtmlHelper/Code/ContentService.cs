﻿using System;
using System.Web;

namespace PimpinOutHtmlHelper.Code
{
    //Okay, so this is just storing the content in the session. Not what you would
    //  normally do...but I hope you get the idea.
    public class ContentService
    {
        public string GetContent(string key)
        {
            InitializeDataStore();

            if (HttpContext.Current == null)
            {
                return String.Empty;
            }
            else
            {
                string contentKey = "content_" + key;
                if (HttpContext.Current.Session[contentKey] != null)
                    return HttpContext.Current.Session[contentKey].ToString();
                else
                    return String.Empty;
            }
        }

        public void SetContent(string key, string value)
        {
            if (HttpContext.Current != null)
            {
                string contentKey = "content_" + key;
                HttpContext.Current.Session[contentKey] = value;
            }
        }

        private void InitializeDataStore()
        {
            string contentKey = "content_HomePage";
            if (HttpContext.Current.Session[contentKey] != null)
                return;

            SetContent("HomePage", "<p>This is dynamic content.</p>");

        }

    }
}
