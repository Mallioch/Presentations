﻿using System;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;

namespace PimpinOutHtmlHelper.Code
{
    public static class InputExtensions
    {
        public static MvcHtmlString CoolTextBox<T, TResult>(this HtmlHelper<T> helper, Expression<Func<T, TResult>> expression)
        {
            string labelValue = GetName(expression);
            string label = String.Format("<label for=\"{0}\">{0}</label>", labelValue);

            object textBoxValue = GetValue(helper, expression);
            string input = String.Format("<input type=\"text\" name=\"{1}\" value=\"{0}\" />", textBoxValue, labelValue);

            var mvcString = MvcHtmlString.Create(label + input);
            return mvcString;
        }

        private static string GetName<T, TResult>(Expression<Func<T, TResult>> expression)
        {
            switch (expression.Body.NodeType)
            {
                case ExpressionType.MemberAccess:
                    var memberExpr = expression.Body as MemberExpression;
                    return memberExpr.Member.Name;
                default:
                    return "wrong";
            }
        }

        private static object GetValue<T, TResult>(HtmlHelper<T> helper, Expression<Func<T, TResult>> expression)
        {
            T model = helper.ViewData.Model;

            if (model == null)
                return default(TResult);

            Func<T, TResult> compiledExpression = expression.Compile();
            return compiledExpression(model);
        }

    }
}
